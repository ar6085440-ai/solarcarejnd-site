
SolarCareJND Website Starter

Steps to run locally:

1. Extract the ZIP.
2. Install dependencies:
   npm install
3. Run dev server:
   npm run dev
4. Open the URL shown by Vite (usually http://localhost:5173)

Tailwind is pre-configured (tailwindcss + postcss). Replace images in /public:
- logo.png
- demo-photo.jpg
- mascot-clean.png

Booking form saves to localStorage. To use Firebase / server, replace booking handlers in src/App.jsx.
